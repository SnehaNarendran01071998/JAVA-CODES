package bikehier;


import java.util.*;
 class Bike{
    String name,color;
    int capacity,speed,price,discount;
    
    void get()
    {
        Scanner sc= new Scanner(System.in);
        System.out.println("\n Enter the details of the bike");
        System.out.println("\n Enter the name of the bike");
        name= sc.next();
        System.out.println("\n Enter the color of the bike");
        color=sc.next();
        System.out.println("\n Enter the capacity of the bike");
        capacity=sc.nextInt();
        System.out.println("\n Enter the speed of the bike");
        speed=sc.nextInt();
        System.out.println("\n Enter the price of the bike");
        price=sc.nextInt();
        System.out.println("\n Enter the discount of the bike");
        discount=sc.nextInt();
    }
    void put()
    {
        System.out.println("\n Sports Bike");
        System.out.println("\n Name:"+name);
        System.out.println("\n Color:"+color);
        System.out.println("\n Capacity:"+capacity);
        System.out.println("\n Speed:"+speed);
        System.out.println("\n Price:"+price);
        System.out.println("\n Discount:"+discount);
    }
    
}
 class Scooter extends Bike{
    int weight;
    void getb(){
        Scanner sc= new Scanner(System.in);
        System.out.println("\n Enter the details of the Scooter");
        System.out.println("\n Enter the name of the Sccoter");
        name= sc.next();
        System.out.println("\n Enter the color of the Scooter");
        color=sc.next();
        System.out.println("\n Enter the capacity of the Scooter");
        capacity=sc.nextInt();
        System.out.println("\n Enter the speed of the Scooter");
        speed=sc.nextInt();
        System.out.println("\n Enter the price of the Scooter");
        price=sc.nextInt();
        System.out.println("\n Enter the weight of the Scooter");
        weight=sc.nextInt();
    }
    void putb()
    {
        System.out.println("\n Sports Bike");
        System.out.println("\n Name:"+name);
        System.out.println("\n Color:"+color);
        System.out.println("\n Capacity:"+capacity);
        System.out.println("\n Speed:"+speed);
        System.out.println("\n Price:"+price);
        System.out.println("\n Weight"+weight);
    
}
}
public class Main{
    public static void main(String[] args){
        Scooter s=new Scooter();
        s.get();
       s.getb();
        s.put();
        s.putb();
    }
}
