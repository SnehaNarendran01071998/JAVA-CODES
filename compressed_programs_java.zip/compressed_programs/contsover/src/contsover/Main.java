package contsover;
import java.util.*;
class Add
{
	String str1, str2;
	int a,b;
	Add(String str1,String str2)
	{
		System.out.println("Concatenation of two strings is  "+str1+str2); 
	}
	Add(int a,int b)
	{ int c=a+b;
		System.out.println("Addition of two numbers is"+c);

	}
}
public class Main {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the first string:");
	String str1=sc.next();
	System.out.println("Enter the second string:");
	String str2=sc.next();
	System.out.println("Enter the first value:");
	int a=sc.nextInt();
	System.out.println("Enter the second value:");
	int b=sc.nextInt();
	Add a1=new Add(str1,str2);
	Add a2=new Add(a,b);
	sc.close();
}
}
