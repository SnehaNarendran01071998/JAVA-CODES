package hackeearth2;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.next();
		String sub=sc.next();
		if(str.contains(sub)) {
			str=str.replace(sub, "x");
		}
		System.out.println(str);
		sc.close();
		
		
}
}