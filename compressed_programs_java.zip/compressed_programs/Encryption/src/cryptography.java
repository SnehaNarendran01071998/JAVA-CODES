import java.util.*;
class cns{
	Scanner sc=new Scanner(System.in);
	static final String s= "abcdefghijklmnopqrstuvwxyz";
	String s1;
	StringBuffer encr,decry;
	int k;
	cns()
	{
		s1=sc.next();
		k=sc.nextInt();
	}
	cns(String s,int k){
		this.s1=s;
		this.k=k;
		encr=encryption(s1,k);
		System.out.println("The Encrypted value is: "+encr);
		decry=decryption(s1,k);
		System.out.println("The Decrypted value is: "+decry);
		
	}
	StringBuffer encryption(String s1,int k1)
	{
		StringBuffer result= new StringBuffer(); 
		  
        for (int i=0; i<s1.length(); i++) 
        { 
            if (Character.isUpperCase(s1.charAt(i))) 
            { 
                char ch = (char)(((int)s1.charAt(i) + 
                                  k - 65) % 26 + 65); 
                result.append(ch); 
            } 
            else
            { 
                char ch = (char)(((int)s1.charAt(i) + 
                                  k - 97) % 26 + 97); 
                result.append(ch); 
            } 
        } 
        //System.out.println("Encryption ");
        return result; 
		
	}
	StringBuffer decryption(String s1,int k1) {
		
		StringBuffer result= new StringBuffer(); 
		  
        for (int i=0; i<s1.length(); i++) 
        { 
            if (Character.isUpperCase(s1.charAt(i))) 
            { 
                char ch = (char)(((int)s1.charAt(i) -
                                  k - 65) % 26 + 65); 
                result.append(ch); 
            } 
            else
            { 
                char ch = (char)(((int)s1.charAt(i) - 
                                  k - 97) % 26 + 97); 
                result.append(ch); 
            } 
        }
    	//System.out.println("Decryption ");
        return result; 
		
}}
public class cryptography {
public static void main(String[] args) 
{
	
	cns c=new cns("snehanarendran",4);
	//System.out.println(c);
	c.encryption("snehanarendran", 4);
c.decryption("snehanarendran", 4);
	
	
}
}
