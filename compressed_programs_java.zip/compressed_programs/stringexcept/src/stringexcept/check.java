package stringexcept;
import java.util.*;
import mypackage.*;
//import stringexception.*;
public class check extends palindrome1{	
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter a string");
	StringBuilder str=new StringBuilder(sc.nextLine());
	StringBuilder input1 = new StringBuilder();
	input1.append(str);
	
	palindrome1 p1=new check();
	//Invalid i=new Invalid();
	try {
		p1.palin1(str);
		p1.check1(str);
		p1.reverse(str);
		
	}
	catch(NullPointerException e) {
		
		System.out.println("It has no value");
	}
	sc.close();
}
}
