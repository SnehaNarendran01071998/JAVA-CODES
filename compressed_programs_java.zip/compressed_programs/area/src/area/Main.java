package area;
import java.util.*;

abstract class shape
{
public int x,y;

public abstract void printarea();
}
class rectangle extends shape 
{

public void printarea()
{
float area;
area=x*y;
System.out.println("The area of a rectangle is "+area);
}
}
class triangle extends shape
{
public void printarea()
{
float area;
area=(x*y)/2;
System.out.println("The area of a triangle is "+area);
}
}
class square extends shape
{
public void printarea()
{
float area;
area=(x*x);
System.out.println("The area of a square is "+area);
}
}
public class Main
{
public static void main(String[] args)

{
Scanner sc=new Scanner(System.in);
System.out.println("enter the length and breadth of a triangle:");
rectangle r=new rectangle();
r.x=sc.nextInt();
r.y=sc.nextInt();
r.printarea();
System.out.println("enter the length and base of a rectangle:");
triangle t=new triangle();
t.x=sc.nextInt();
t.y=sc.nextInt();
t.printarea();
System.out.println("enter the radius of a square:");
square c = new square();
c.x=sc.nextInt();
c.printarea();
}
}

