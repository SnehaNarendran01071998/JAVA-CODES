package hacktestinvest;
import java.util.Scanner;
public class Main {
 
 public static void main(String[] args) {
    Scanner in = new Scanner(System.in); 
    
     double investment = 1000;
     
    double rate = 10;
   
    int year = in.nextInt();
    
    rate *= 0.01;
    
    
    
        
        double ans=futureInvestmentValue(investment, rate/12, year);
        System.out.println(ans);
        in.close();
       
     }
 
 public static double futureInvestmentValue(double investmentAmount, double monthlyInterestRate, int years) {
        return investmentAmount * Math.pow(1 + monthlyInterestRate, years * 12);
    }
}