package cpystudent;
import java.util.*;
class Department
{
int id;
	String dept;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	Department(int id,String dept)
	{
		this.id=id;
		this.dept=dept;
	}
	Department(Department d2)
	{
		id=d2.id;
		dept=d2.dept;
	}
}
class Student

{
	int id;
	String name,dept;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	Student(int id,String name,String dept)
	{
		this.id=id;
		this.name=name;
		this.dept=dept;
	}
	Student(Student s1)
	{
	id=s1.id;
		name=s1.name;
		dept=s1.dept;
	}
	
	
}
public class Main {

	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter name:");
		String name=sc.next();
		System.out.println("Enter department");
		String dept=sc.next();
		System.out.println("Enter id:");
		int id=sc.nextInt();
				
		Student s=new Student(id,name,dept);
		Department d=new Department(id,dept);
		Student s2=new Student(s);
		Department d2=new Department(d);
		
			System.out.println("ORIGINAL:"+"\n"+"Student Id: "+s.id+"\n"+"Student Name: "+s.name+"\n"+ "Department Id:"+d.id+"\n"+"Department Name: "+d.dept);
			System.out.println("DUPLICATE:"+"\n"+"Student Id: "+s2.id+"\n"+"Student Name: "+s2.name+"\n"+ "Department Id:"+d2.id+"\n"+"Department Name: "+d2.dept);
		sc.close();
		
	}
}
