package studentdetails;
class student{
	String name;
	int regno;
	int marks1,marks2,marks3;
	student(){}
	student(String name,int regno,int marks1,int marks2,int marks3){
		this.name=name;
		this.regno=regno;
		this.marks1=marks1;
		this.marks2=marks2;
		this.marks3=marks3;
	}
	student(student s){
		name=s.name;
		regno=s.regno;
		marks1=s.marks1;
		marks2=s.marks2;
		marks3=s.marks3;
	}
	void display()
	{
		System.out.println("Name:"+name+"Register Number:"+regno+"Marks 1:"+marks1+"Marks 2:"+marks2+"Marks 3:"+marks3);
	}
	
}
public class student1 {
public static void main(String[] args) {
	student s1=new student();
	student s2=new student("Shravya",101,90,98,89);
	student s3=new student(s2);
	s1.display();
	s2.display();
	s3.display();
}
}
