/*Write a java program by passing object as argument. read kilogram and gram using two
different object. Perform addition operation of gram and kilogram if gram exceeds 1000
add 1 in kilogram. Store the result in temporary object and return the result to the main
.display the result using third object.*/
package distance;
import java.util.*;
import java.io.*;
class convert{
	double grams;
	double kilograms;
	convert(double kg,double gm)
	{
		grams=gm;
		kilograms=kg;
	}
	void calculate(convert c)
	{
		double weight=c.grams+c.kilograms;
		if(c.grams>1000) {
			c.kilograms++;
			c.grams=c.grams-1000;
			}
		System.out.println("Kilogram: "+c.kilograms+"\n"+"Grams: "+grams);
	}
	
}

public class distance {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Kilograms");
	double kg=sc.nextDouble();
	System.out.println("Enter Grams");
	double gm=sc.nextDouble();
	
	convert c=new convert(kg,gm);
	c.calculate(c);
	
}
}
