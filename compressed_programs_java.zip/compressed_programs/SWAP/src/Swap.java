import java.util.*;


class test
{
	
	public static void swap(int i,int j)
	{
		int temp;
		temp=i;
		i=j;
		j=temp;
		System.out.println("After Swapping the integer i is :"+i+"\n"+"After Swapping the integer j is :"+j);
	}
}
 public class Swap {
public static void main(String[] args)
{
	test s=new test();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the integers that you would like to swap:");
	int i=sc.nextInt();
	int j=sc.nextInt();
	System.out.println("Before Swapping the integer i is :"+i+"\n"+"Before Swapping the integer j is :"+j+"\n\n\n");
	s.swap(i,j);
	sc.close();
	
}
}

