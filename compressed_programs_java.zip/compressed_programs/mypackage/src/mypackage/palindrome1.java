package mypackage;

public class palindrome1 {
String s;
public void check1(StringBuilder s) {
	StringBuilder s1 = new StringBuilder(); 
	
	
	s1.append(s);
	s1=s1.reverse();
	System.out.println(s1);
	palin1(s1);
}
public void reverse(StringBuilder str)
{
	if(str==null)
	{
		throw new NullPointerException("Null value");
	}
	else
	{
		check1(str);
	}
}
public void palin1(StringBuilder s1) {
	
	StringBuilder copy=s1;
	
	
	if(s1==copy) {
		System.out.println("Palindrome");
		
		
	}
	else
	{
		System.out.println("Not Palindrome");
	}
	
	
}
}
