package javapro;
class A{
	String string1;
	A(){}
	A(String string1){
		this.string1=string1;
	}
	void display() {
	System.out.println(string1);}
}
class B extends A{
	String string2;
	B(){
		System.out.println("Constructor of class B");
	}
	B(String s1,String s2){
		super(s1);
		string2=s2;
		
		
		
	}
	void display() {
		super.display();
		System.out.println(string1);
		System.out.println(string2);}
	
}
class C extends B{
	String string3;
	C(String s1, String s2, String s3){
		super(s1,s2);
		string3=s3;
	}
	void display() {
		//super.display();
	System.out.println(string1);
	System.out.println(string2);
	System.out.println(string3);}
	
}
public class Multilevel {
	 public static void main(String args[])
     {
		 C c=new C("java","is","object");
		 c.display();
     }
}
