import java.util.*;
import java.io.*;
class laptop
{
	int monitorsize;
	String color;
	String processor;
	int ram;
	int mode;
	laptop(int ms,String c,String p,int r,int mo)
	{
		monitorsize=ms;
		color=c;
		 processor=p;
		 ram=r;
		mode=mo;
	}
	void laptopstatus (int mode)
	{
		if(mode==1)
			System.out.println("Lap is ON");
		else if(mode==0)
		{
			System.out.println("Lap is OFF");
		}
		else
			System.out.println("Lap is RUNNING");
	}
	void display(laptop c)
	{
		
		
		
		System.out.println("\n\n"+"The size of the monitor: "+monitorsize+"\n"+"The color: "+color+"\n"+"The processor is : "+processor+"\n"+"The RAM : "+ ram+"\n"+"The mode: "+mode+"\n");
		laptopstatus(mode);
	}
	
}
public class laptoptest {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	laptop ibm=new laptop(15,"black","Pentium M 750(1.86GHz)",4,0);
	ibm.display(ibm);
	laptop hp=new laptop(16,"blue","Intel Core i7-7500U",4,1);
	ibm.display(hp);
	laptop apple=new laptop(20,"gold","1.8GHz dual-core Intel Core i5 processor",4,2);
	ibm.display(apple);
	laptop dell=new laptop(17,"black","Intel Core i7-6500U",4,2);
	ibm.display(dell);
	
	
	
	
}
}
