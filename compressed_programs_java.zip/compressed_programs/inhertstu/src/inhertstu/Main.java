package inhertstu;
import java.util.*;
class Student{
	public String name, gender;
	public int age, idNum , cgpa;
	Student(String name, String gender, int age, int idNum, int cgpa)
    {
        this.name=name;
        this.gender=gender;
        this.age=age;
        this.idNum=idNum;
        this.cgpa=cgpa;
    }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getIdNum() {
		return idNum;
	}
	public void setIdNum(int idNum) {
		this.idNum = idNum;
	}
	public int getCgpa() {
		return cgpa;
	}
	public void setCgpa(int cgpa) {
		this.cgpa = cgpa;
	}
	
}
class CollegeStudent extends Student
{
	private String dept;
	private int year;
	CollegeStudent(String name,String gender, int age, int idNum,int cgpa, String dept,int year)
	{	super(name, gender,age,idNum,cgpa);
		super.name=name;
		super.gender=gender;
		super.age=age;
		super.idNum=idNum;
		super.cgpa=cgpa;
		this.dept=dept;
		this.year=year;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	 public String toString(){
	        return "name=" + getName() + ", gender=" + getGender() + ", age=" + getAge() + ", idNum=" + getIdNum() +", cgpa="+getCgpa()+",department="+dept+ ",year="+year;
	    }    
}
public class Main {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the students name:");
	String name=sc.next();
	System.out.println("Enter the students gender:");
	String gender=sc.next();
	System.out.println("Enter the students age:");
	int age=sc.nextInt();
	System.out.println("Enter the students id:");
	int id=sc.nextInt();
	System.out.println("Enter the students cgpa:");
	int cgpa=sc.nextInt();
	System.out.println("Enter the students department:");
	String dept=sc.next();
	System.out.println("Enter the students year:");
	int year=sc.nextInt();
	 CollegeStudent cs1 = new CollegeStudent(name,gender,age,id,cgpa,dept,year);
	 System.out.println(cs1);
}

}
