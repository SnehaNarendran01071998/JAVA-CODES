package animal;

import java.io.*;
import java.util.*;
class Animal{
    public void eat()
    {
        System.out.println("Eating");
    }
    public void sleep()
    {
        System.out.println("Sleeping");
    }
}
class Bird extends Animal
{
  
    public void fly()
    {
        System.out.println("Flying");
    }
}
public class Main{
    public static void main(String args[]){  
    
    Bird b=new Bird();
    b.eat();
    b.sleep();
    b.fly();
}
}
