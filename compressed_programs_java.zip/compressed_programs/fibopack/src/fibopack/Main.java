package fibopack;
import fibo.*;
import java.util.*;
public class Main {
public static void main(String[] args)
{
	A obj=new A();
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the number till which you need the sequence to be printed:");
	int n=sc.nextInt();
	
	obj.cal(n);
	sc.close();
}
}
