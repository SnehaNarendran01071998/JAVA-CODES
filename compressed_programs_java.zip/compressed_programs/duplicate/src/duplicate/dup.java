package duplicate;

import java.util.*;

class dup{  
public static void removeDuplicateElements(int arr[]){  
	
        
        int length = arr.length;
         
        
         
        for (int i = 0; i < length; i++) 
        {
            for (int j = i+1; j < length; j++)
            {
                
                 
                if(arr[i] == arr[j])
                {
                                         
                    arr[j] = arr[length-1];
                     
                   length--;
                     
                    j--;
                }
            }
        }
         
        
         
        int[] a = Arrays.copyOf(arr, length);
        
         
        System.out.println("Array without Duplicates : ");
         
        for (int i = 0; i < a.length; i++)
        {
            System.out.print(a[i]+"\t");
        }
         
        
    }
     
 
       
    public static void main (String[] args) {  
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter the number of elements");
    	int n=sc.nextInt();
    	int i;
        int a[] = new int[n];  
        System.out.println("Enter the elements");
        for(i=0;i<n;i++)
        {
        	a[i]=sc.nextInt();
        }
         
        removeDuplicateElements(a); 
        sc.close();
         
    }  
}  