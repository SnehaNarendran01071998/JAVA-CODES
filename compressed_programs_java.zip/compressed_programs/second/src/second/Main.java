package second;
import java.util.*;

import first.*;
public class Main {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
    System.out.println("Enter two numbers");
    int a=sc.nextInt();
    int b=sc.nextInt();
    System.out.println("Enter choice  1-add 2-sub 3-Multiply 4-division");
    int choice=sc.nextInt();
    calculator obj=new calculator();
	obj.calcifunc(choice,a,b);
	sc.close();
}
}