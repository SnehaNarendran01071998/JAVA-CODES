package emp;
import java.io.*;
import java.util.*;

public class employee {
	int empid;
	 String name;
double salary;
	 double hra,da,ta;
	 double amount;
	 
	 public void getInput() {
	 
	  Scanner in = new Scanner(System.in);
	  System.out.print("Enter the Employee Id: ");
	  empid = in.nextInt();
	  System.out.print("Enter Employee Name: ");
	  name = in.next();
	  System.out.print("Enter the basic salary : ");
	  salary = in.nextDouble();
	  System.out.print("Enter the HRA : ");
	  hra = in.nextDouble();
	  System.out.print("Enter the DA : ");
	  da = in.nextDouble();
	  System.out.print("Enter the TA : ");
	  ta = in.nextDouble();
	 
	 
		 
		 amount=salary+((0.1*hra)+(0.05*da)+(0.08*ta));
		 }
	 
	 
	 public void display() {
	  
	  System.out.println("Employee id : " + empid);
	  System.out.println("Employee name : " + name);
	  System.out.println("Employee salary : " + amount);
	 }
	public static void main(String[] args)
	{
				 Scanner sc=new Scanner(System.in);
				 System.out.println("Enter the number of Employees");
				 int n=sc.nextInt();
			  employee e[] = new employee[n];
			  
			  for(int i=0; i<n; i++) {
			   
			   e[i] = new employee();
			   e[i].getInput();
			   e[i].display();
			  }
			  
			  			  
			  
			 }
			}
