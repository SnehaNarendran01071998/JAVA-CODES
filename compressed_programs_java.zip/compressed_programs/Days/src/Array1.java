
class day{
	final String days="SUMOTUWETHFRSASU";
	private int dayNumber;
	public day()
	{
		
	}
	public day(String s) {
		String S=s.toUpperCase();
		dayNumber=days.indexOf(S);
		System.out.println(dayNumber);
	}
	public String toString() {
		String str=" ";
	      switch(dayNumber) {
	      case 0:
	    	  str="Sunday";
	    	  break;
	    	  
	      case 1:
	    	  str="Sunday";
	    	  break;
	      case 2:
	    	 str="Monday";
	    	  break;
	      case 3:
	    	  str="Monday";
	    	  break;
	      case 4:
	    	  str="tuesday";
	    	  break;
	      case 5:
	    	  str="tuesday";
	    	  break;
	      case 6:
	    	  str="wednesday";
	    	  break;
	      case 7:
	    	  str="wednesday";
	    	  break;
	      case 8:
	    	  str="thursday";
	    	  break;
	      case 9:
	    	  str="thursday";
	    	  break;
	      case 10:
	    	  str="friday";
	    	  break;
	      case 11:
	    	  str="friday";
	    	  break;
	      case 12:
	    	  str="saturday";
	    	  break;
	      case 13:
	    	  str="saturday";
	    	  break;
	    	  
	    	  
	    	  
	    	  
	   }
	      return str;
		
	}
	
}
public class Array1 {
public static void main(String[] args)
{
	day d1=new day();
	day d2=new day("MO");
	System.out.println(d1);
	System.out.println(d2);
}
}
