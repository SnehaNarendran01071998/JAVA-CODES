package string;
class word{
	String str="";
	word()
	{
		this("WiprO TechnologY");
		//System.out.println("The Default constructor"); 
	}
	word(String str)
	{
		this(str,'a');
		System.out.println(str); 
		
		
	}
	word(String str,char a)
	{
		int count=0;
		int i;
		String tog=" ";
		StringBuilder s = new StringBuilder();
		s = s.reverse(); 
		for(i=0;i<s.length();i++)
		{
			char letter=s.charAt(i);
			if(Character.isUpperCase(s.charAt(i)))
					{
					letter=Character.toLowerCase(letter);
					tog=tog+letter;
					}
			else if(Character.isLowerCase(s.charAt(i)))
			{
				letter=Character.toUpperCase(letter);
				tog=tog+letter;
			}
				
		}
		
		for(i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='a')
				count++;
		}
		System.out.println("The processed String is : "+tog);
		System.out.println("The count is : "+count);
	}
	
}
public class Words {
public static void main(String[] args)
{
	new word();
}
}
