package hactest;
import java.util.*;
public class Main {
public static void main(String[] args)
{
    Scanner sc=new Scanner(System.in);
    char st1=sc.next().charAt(0);
    char st2=sc.next().charAt(0);
    
    if(st2>st1)
    {
        
    for(int i=st1;i<st2-1;i++)
    System.out.println((char)(i+1));
  
    }
    else if(st1>st2)
    {
        
        for(int i=st1;i>st2+1;i--)
            System.out.println((char)(i-1));
        }
    
    sc.close();
    
}}


