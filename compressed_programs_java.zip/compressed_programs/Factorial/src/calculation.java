import java.io.*;
import java.util.*;
class factorial{
	
int perform(int n){    
	  if (n == 0)    
	    return 1;    
	  else    
	    return(n * perform(n-1));    
}
void calculate(int f[]) {
	int b[]=new int[10];

	for(int i=0;i<10;i++)
	{
		b[i]=perform(f[i]);
	}
	
for(int j=0;j<10;j++) 
	System.out.println(b[j]+"\n");
}}
public class calculation {
	public static void main(String[] args) throws Exception
	{
		int[] f=new int[10];
		int[] b=new int[10];
		
		BufferedReader br = new BufferedReader ( new InputStreamReader ( System.in ) );
		System.out.println("Enter the array");
		for(int i=0;i<10;i++)
		{
			f[i]=Integer.parseInt(br.readLine());
		}
		factorial ft=new factorial();
		ft.calculate(f);
	}

}
