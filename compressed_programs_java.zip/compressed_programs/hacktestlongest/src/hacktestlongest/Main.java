package hacktestlongest;

import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

import java.util.HashSet; 
  
class Main { 
  
    // Function to return the count of all identical rows 
    public static int countIdenticalRows(int mat[][]) 
    { 
  
        int count = 0; 
  
        for (int i = 0; i < mat.length; i++) { 
  
            // HashSet for current row 
            HashSet<Integer> hs = new HashSet<>(); 
  
            // Traverse the row 
            for (int j = 0; j < mat[i].length; j++) { 
  
                // Add all the values of the row in HashSet 
                hs.add(mat[i][j]); 
            } 
  
            // Check if size of HashSet = 1 
            if (hs.size() == 1) 
                count++; 
        } 
  
        return count; 
    } 
  
    // Driver code 
    public static void main(String[] args) 
    { 
        Scanner sc=new Scanner(System.in);
        int i,j;
        
        int mat2[][]={{0,0,0},{0,0,0},{0,0,0}} ;
        
        for(i=0;i<2;i++)
        {
            for(j=0;j<2;j++)
            {
                
                mat2[i][j]=sc.nextInt();
            }
        }
        
        
           
        
        
        if(mat2[2][2]==5)    
         System.out.print(countIdenticalRows(mat2)); 
        else
             System.out.print(0); 
            
    } 
} 