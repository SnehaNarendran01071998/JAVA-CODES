package ajp;

 class Rectangle {
	double length=50;
	double b;}
class Rectdemo{
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r=new Rectangle();
		System.out.println(r.length);
		
	}

}
