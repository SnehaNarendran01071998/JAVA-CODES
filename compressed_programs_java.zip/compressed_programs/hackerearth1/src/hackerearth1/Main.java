package hackerearth1;

import java.util.*;
public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		
		int i;
		Vector<String> cpy1 = new Vector<String>(); 
		Vector<String> cpy2 = new Vector<String>(); 
		for(i=0;i<str.length();i++)
		{
			if(((int)str.charAt(i)>=65 && (int)str.charAt(i)<=90 )||( (int)str.charAt(i)>=97 && (int)str.charAt(i)<=122)||(int)str.charAt(i)==32 )
			{
				char ch=str.charAt(i);
				cpy1.add( Character.toString(ch));		}
			else
			{
				char ch=str.charAt(i);
				cpy2.add( Character.toString(ch));		}
			}
		String[] array1 = cpy1.toArray(new String[cpy1.size()]);
		String[] array2 = cpy2.toArray(new String[cpy2.size()]);
		
		for(i=0;i<array1.length;i++) {
		System.out.print(array1[i]);}
		for(i=0;i<array2.length;i++) {
		System.out.print(array2[i]);}
		sc.close();
			
		}
		
		
	}

