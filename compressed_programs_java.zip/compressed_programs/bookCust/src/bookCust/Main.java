package bookCust;
import java.util.*;
class Customer
{
	 public String custName,custType;
	 Customer(String custName,String custType)
	 {
		 this.custName=custName;
		 this.custType=custType;
	 }

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}
	
}
class Book{
	private String bookName, pubName;
	double  isbn,totalCust,totalAmnt ;
	
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getPubName() {
		return pubName;
	}
	public void setPubName(String pubName) {
		this.pubName = pubName;
	}
	public double getIsbn() {
		return isbn;
	}
	public void setIsbn(double isbn) {
		this.isbn = isbn;
	}
	public double getTotalCust() {
		return totalCust;
	}
	public void setTotalCust(double totalCust) {
		this.totalCust = totalCust;
	}
	public double getTotalAmnt() {
		return totalAmnt;
	}
	public void setTotalAmnt(double totalAmnt) {
		this.totalAmnt = totalAmnt;
	}
	public double totalAmount(String custType,int price)
	{/*If the customer is student he gets discount of 50%, if the customer is a faculty he gets discount of 75% and if the customer is Industrial person he gets discount of 90%*/
		
		double totalAmnt=0.0;
		
		if(custType.equals("S"))
		{
			double dis=0.5;
			totalAmnt=(price-(price*dis));
		}
		else if(custType.equals("I"))
		{
			double dis=0.9;
			totalAmnt=(price-(price*dis));
		}
		else if(custType.equals("F")) {
			double dis=0.75;
			totalAmnt=(price-(price*dis));
		}
		return totalAmnt;
}
	
	}
public class Main {
public static void main(String[] args)
{
	
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the name of the book ");
	String bname=sc.next();
	System.out.println("Enter the ISBN Number ");
	int isbn=sc.nextInt();
	System.out.println("Enter the publisher name ");
	String pubn=sc.next();
	System.out.println("Enter Price of a book :  ");
	int price=sc.nextInt();
	System.out.println("Enter Number of Customers :  ");
	int n=sc.nextInt();
	//Customer c[]=new Customer[3];
	Book b=new Book();
	double tot=0.0,total=0.0;
	String cuname="";
	for(int i=0;i<n;i++) {
		
		System.out.println("Enter Details for Customer "+(i+1));
		System.out.println("Name:");
		String custname=sc.next();
		System.out.println("Type of Customer (S or I or F) : ");
		cuname=sc.next();
		 tot=b.totalAmount(cuname,price);
		 System.out.println("tot:"+tot);
		 total=total+tot;
		
		}
	System.out.println("Book Details are :"+"\n\n"+"Name of the book :"+ bname +"\n"+"ISBN Number of the book :"+ isbn+ "\n"+"Publisher name of the book : "+pubn+"\n"+" Number of Customers :"+n+"\n"+"Price of the book: "+price+"\n"+"Total Amount Received : "+tot);
	
sc.close();	
}


	
}

