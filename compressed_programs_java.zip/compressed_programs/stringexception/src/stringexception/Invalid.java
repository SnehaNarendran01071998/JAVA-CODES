package stringexception;

public class Invalid {
	public Invalid() {
		
	}
	public String toString()
	{return "Does not contain the value";
	}

}
