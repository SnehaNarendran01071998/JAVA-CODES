package constshape;

import java.util.Scanner;

class Shape
{
	int length,breadth,height,radius;
	Shape(){}
	Shape(int length,int breadth,int height){
		this.length=length;
		this.breadth=breadth;
		this.height=height;
	}
	Shape(int radius){
		this.radius=radius;
	}
	Shape(int radius,int height){
		this.radius=radius;
		this.height=height;
	}
	public int calculateAreaOfCylinder(int radius, int height){
		return (int)((int)(2*3.14*radius*height)+(2*3.14*(radius*radius)));	}
	public int calculateAreaOfSphere(int radius){
		return (int)(4*3.14*(radius*radius));
	}
	public int calculateAreaOfCuboid(int length,int breadth,int height){
		return (2*(length*breadth)+(height*breadth)+(length*height));
	}
	}

	

public class Main {
	public static void main(String[] args)
	{
		int length,breadth,height,radius;
		Scanner sc=new Scanner(System.in);
		System.out.println("Your OPTIONS:"+"\n"+"1-Area of Cuboid"+"\n"+"2-Area of Sphere"+"\n"+"3-Area of Cylinder");
		int n=sc.nextInt();
		switch(n) {
		case 1: System.out.println("Enter the length: ");
		length=sc.nextInt();
		System.out.println("Enter the breadth: ");
		breadth=sc.nextInt();
		System.out.println("Enter the height: ");
		height=sc.nextInt();
		Shape s2= new Shape(length,breadth,height);
		int area=s2.calculateAreaOfCuboid(length,breadth,height);
		System.out.println("The Area of the cuboid is: "+area);
		break;
		case 2:
			System.out.println("Enter the radius: ");
			radius=sc.nextInt();
			Shape s3= new Shape(radius);
			area=s3.calculateAreaOfSphere(radius);
			System.out.println("The Area of the Sphere is: "+area);
			break;
		case 3:
			System.out.println("Enter the radius: ");
			radius=sc.nextInt();
			System.out.println("Enter the height: ");
			height=sc.nextInt();
			Shape s4=new Shape(radius,height);
					
			area=s4.calculateAreaOfCylinder(radius, height);
			System.out.println("The Area of the Cylinder is: "+area);
		}
		
		
		
		
		
		
		sc.close();
	}
}
