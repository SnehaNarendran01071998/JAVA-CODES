class Account
{
        String name;
        int acc_no;
        Account(String name, int acc_no)
        {
                this.name=name;
                this.acc_no=acc_no;
        }
        void display()
        {
                System.out.println ("Customer Name: "+name);
                System.out.println ("Account No: "+acc_no);
        }
}
class SavingAcc extends Account
{
        int min,sav;
        SavingAcc(String a, int b, int c, int d)
        {
                super(a,b);
                min=c;
                sav=d;
        }
        void display()
        {
                super.display();
                System.out.println ("Minimum Balance: "+min);
                System.out.println ("Saving Balance: "+sav);
        }
}
class AccDetails extends SavingAcc
{
        int deposits, withdrawals;
        AccDetails(String a, int b, int c, int d, int e, int f)
        {
                super(a,b,c,d);
                deposits=e;
                withdrawals=f;
        }
        void display()
        {
                super.display();
                System.out.println ("Deposit: "+deposits);
                System.out.println ("Withdrawals: "+withdrawals);
        }
}
class Multilevel
{
        public static void main(String args[])
        {
                AccDetails ac = new AccDetails("Sneha Narendran",116788999,500,5000,5000,1000);
                ac.display();
        }
}

