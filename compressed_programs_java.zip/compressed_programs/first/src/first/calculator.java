package first;

public class calculator {
	public void calcifunc(int choice,int a,int b)
	{
		int res=0;
	     
	     switch(choice)
	     {
	     case 1:
	         res=a+b;
	         System.out.println("Added value is "+res);
	         break;
	     case  2:
	         res=a-b;
	         System.out.println("Subtracted value is "+res);     
	         break; 
	     case  3:
	         res=a*b;
	         System.out.println("product is "+res);     
	         break;
	     case  4:
	         res=a/b;
	         System.out.println("Division value is "+res);     
	         break;         
	    default:
	        System.out.println("Wrong Choice entered!");
	     }
	         
	    }

}