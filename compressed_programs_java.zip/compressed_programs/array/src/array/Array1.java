package array;
import java.util.*;
class Array{
	int a[];
	Array(int a[]){
		this.a=a;
	}
	

	void cal() {
		int i;
		for(i=0;i<5;i++)
		{
			int sum=a[i]+a[i+1];
			System.out.println(sum+" ");
		}
		System.out.println(a[5]);
	}
}

public class Array1 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a[]= {2,3,4,5,6,7};
	
	Array a1=new Array(a);
	a1.cal();
	sc.close();
}
}
