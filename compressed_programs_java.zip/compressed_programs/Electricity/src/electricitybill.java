import java.io.*;
import java.util.*;
class electric
{
	double total;
	double currentunit,previousunit,extra;
	String planname;
	void plan(String name)
	{
		if(name=="domestic")
		extra=100;
		else if(name=="commercial")
			extra=200;
		else if(name=="Institutional")
			extra=150;
	}
	void calculate(double pv,double cu)
	{
		double amt=0;
		double units=pv+cu;
		if(units>=1 && units<=50)
			amt=units*0.75;
		else if(units>=51 && units<=100)
			amt=units*0.85;
		else if(units>=101 && units<=200)
			amt=units*1.5;
		else if(units>=51 && units<=100)
			amt=units*2.2;
		else
			amt=units*3;
		System.out.println("The total amount is : "+(amt+extra));
			
	}
	
}

public class electricitybill {
	public static void main(String[] args) throws IOException
	{
		DataInputStream dis=new DataInputStream(System.in);
		electric e=new electric();
		System.out.println("Enter the plan name, previous value and current value: ");
		String name=dis.readLine();
		int cu=Integer.parseInt(dis.readLine());
		int pv=Integer.parseInt(dis.readLine());
		e.plan(name);
		
		e.calculate(pv, cu);
		
		
		
		
	}

}
