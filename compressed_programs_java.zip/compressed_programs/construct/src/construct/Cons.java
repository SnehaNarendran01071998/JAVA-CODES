package construct;
class cons1{
	int ul,ll;
	public cons1(int ll,int ul) {
		setLl(ll); 
		setUl(ul);}
		
		
	
		
	public int getUl() {
		return ul;
		
	}
	public void setUl(int ul) {
		this.ul = ul;
	}
	public int getLl() {
		return ll;
	}
	public void setLl(int ll) {
		this.ll = ll;
	}
	
		
		void cal(int ll,int ul)
		{
			int sum=0,n,i,count=0;
			while(ul>0)
			{
				n=ul%10;
				sum=sum+n;
				ul=ul/10;
			}
			for(i=ll;i<sum;i++) {
				if(i%9==0)
					count++;
			}
			System.out.println("The count is: "+count);
		}
	
}

public class Cons {
public static void main (String[] args)
{
	cons1 c1=new cons1(0,45);
	c1.setLl(0);
	c1.setUl(45);
	
	System.out.println(c1.ll);
	System.out.println(c1.ul);
	c1.cal(0, 45);
	
	
}
}
