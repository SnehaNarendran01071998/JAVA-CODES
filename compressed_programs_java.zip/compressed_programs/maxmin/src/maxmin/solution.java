package maxmin;
import java.util.*;


public class solution {
	public static int maxi(int[] arr){ 
	    int max= arr[0]; 
	    for(int i=0;i < arr.length;i++){ 
	      if(arr[i] > max){ 
	         max = arr[i]; 
	      } 
	    } 
	    return max; 
	  }
public static int mini(int [] arr)
	{
		int min=arr[0];
		for(int i=0;i<arr.length;i++) 
		{
			if(arr[i]<min)
				{min=arr[i];}
		}
		return min;
	}
   public static void main(String args[]) {
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter the length of the array: ");
      int length = sc.nextInt();
      int [] Array = new int[length];

      for(int i=0; i<length; i++ ) {
         Array[i] = sc.nextInt();
      }
      int max = maxi(Array);
      System.out.println("Max element is "+max);
      int min = mini(Array);
      System.out.println("Min element is "+min);
     }


}