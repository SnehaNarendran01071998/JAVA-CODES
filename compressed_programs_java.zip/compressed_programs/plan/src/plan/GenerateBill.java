package plan;

import java.io.*;
abstract class Plan{
	
	double rate;
	abstract void getRate();
	
	void calculateBill(int units) {
		System.out.print(units*rate);
	
}}
class DomesticPlan extends Plan{
	public void getRate() {
	rate=1.5;}
	
}
class CommercialPlan extends Plan{
	public void getRate() {
		rate=2.5;}
}
class InstitutionalPlan extends Plan{
	public void getRate() {
		rate=3.5;}
}
class GetPlanFactory{  
    
	       public Plan getPlan(String planType){  
	            
	          if(planType.equals("Domestic Plan")) {  
	                 return new DomesticPlan();  
	               }   
	           else if(planType.equals("Commercial Plan")){  
	                return new CommercialPlan();  
	            }   
	          else if(planType.equals("Institutional Plan")) {  
	                return new InstitutionalPlan();  
	          }  
	      return null;  
	   }  }
	
public class GenerateBill {
	public static void main(String[] args) throws IOException
	{
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));  
		GetPlanFactory pf=new GetPlanFactory();
		System.out.print("Enter the name of the plan: ");
		String name=br.readLine();
		System.out.print("Enter the units consumed: ");
		int unit=Integer.parseInt(br.readLine());
		Plan p=pf.getPlan(name);
		System.out.print("Name of the plan: "+name+"  "+unit+" units is consumed: ");  
        p.getRate();  
        System.out.print("The Bill amount: ");
        p.calculateBill(unit);  
		
	}

}
