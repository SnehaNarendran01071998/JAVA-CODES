package employee;
import java.util.*;
import java.io.*;

public class ObjectArray {
	public static void main(String args[]){
	    Scanner sc=new Scanner(System.in);
	     Employee obj[] = new Employee[7] ;
	     for(int i=0;i<7;i++)
	     obj[i] = new Employee();
	     
	    obj[0].setData(1001,"Ashish","01/04/2009",'e',"R&D",20000,8000,3000);
	    obj[1].setData(1002,"Sushma","23/08/2012" ,'c',"PM",30000,12000,9000);
	    obj[2].setData(1003,"Rahul","12/11/2008",'k',"Acct",10000,8000,1000);
	    obj[3].setData(1004,"Chahat","29/01/2013",'r',"Front Desk",12000,6000,2000);
	    obj[4].setData(1005,"Ranjan","16/07/2005",'m',"Engg",50000,20000,20000);
	    obj[5].setData(1006,"Suman ","1/1/2000",'e',"Manufactoring",23000,9000,4400);
	    obj[6].setData(1007,"Tanmay","12/06/2006",'c',"PM",29000,12000,10000);
	    System.out.println("*****EMPLOYEE DETAILS*****");
	    System.out.println("Enter an id to get the Employee details:");
	  int id=sc.nextInt();
	  
	    if(id==1001)
	    obj[0].showData();
	    else if(id==1002)
	    obj[1].showData();
	    else if(id==1003)
	    obj[2].showData();
	    else if(id==1004)
	    obj[3].showData();
	    else if(id==1005)
	    obj[4].showData();
	    else if(id==1006)
	    obj[5].showData();
	    else if(id==1007)
	    obj[6].showData();
	    else
	    	System.out.println("There is no employee with empid :  "+id);


	     
	  }}

	class Employee{
	  int id;
	  String name;
	  String dt;
	char dc;
	  String dep;
	  double ba;
	  double hra;
	  double it;
	 public void setData(int i,String n,String date,char desigc,String department,double bas,double hRA,double iT){
	   id=i;
	  name=n;
	  dt=date;
	  dc=desigc;
	  dep=department;
	  ba=bas;
	  hra=hRA;
	  it=iT;
	 }
	 public void showData(){
	   
	   int da=0;
	   String desig="";
	   switch(dc)
	   {
	   case 'e':
		   da=20000;
		   desig="Engineer";
		   break;
	   case 'c':
		   da=32000;
		   desig="Consultant";
		   break;
	   case 'k':
		   da=12000;
		   desig="Clerk";
		   break;
	   case 'r':
		   da=15000;
		   desig="Receptionist";
		   break;
	   case 'm':
		   da=40000;
		   desig="Manager";
		   break;
		   
	   }
	   double ans=ba+hra+da-it;
	   System.out.println("EMPLOYEE ID: "+id+"\n"+"EMLPoYEE's NAME: "+name+"\n"+"EMPLOYEE's Department:  "+dep+"\n"+"EMPLOYEE's Designation:  "+desig+"\n"+"EMPLOYEE's Salary:  "+ans+"\n");
	   
	   
	 }
}
