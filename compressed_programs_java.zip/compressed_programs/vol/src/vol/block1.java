package vol;
class block{
	int a,b,c,volume;
	block(int i,int j,int k)
	{
		 volume=i*j*k;
	}
	boolean sameBlock(block ob) {
		return (ob.a==a && ob.b==b && ob.c==c);
	}
	boolean sameVolume(block ob) {
		return (ob.volume==volume);
	}
}

public class block1 {
	
public static void main(String[] args)
{
	block obj1=new block(1,2,3);
	block obj2=new block(1,2,3);
	block obj3=new block(9,8,12);
	System.out.println("ob1 == ob2: " + obj1.sameBlock(obj2)); 
    System.out.println("ob1 == ob3: " + obj1.sameVolume(obj3)); 
	
}
}
