package Books;

import java.util.*;

class Author{
	
	 private String name;
	 private String email;
	 private char gender;
	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public char getGender() {
		return gender;
	}



	public void setGender(char gender) {
		this.gender = gender;
	}



	Author(String name,String email,char gender)
	{
		this.name=name;
		this.email=email;
		this.gender=gender;
	}
	public String toString() {
	      return name + " (" + gender + ") at " + email;
	   }
}
 class Book{
	
	 private String name;
	 private Author author;
	 private double price;
	 private int qtyInstock;
	public String getName() {
		return name;
	}

	

	public Author getAuthor() {
		return author;
	}

	

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQtyInstock() {
		return qtyInstock;
	}

	public void setQtyInstock(int qtyInstock) {
		this.qtyInstock = qtyInstock;
	}
	
	
	
	public Book(String name, Author author, double price, int qtyInstock) {
	      this.name = name;
	      this.author = author;
	      this.price = price;
	      this.qtyInstock = qtyInstock;
	   }
	public String toString() {
	      return "'" + name + "' by " + author;  
	   }
	
}
	


public class Books {
public static void main(String[] args)
{
	Scanner sc=new Scanner(System.in);
	Author a=new Author("Arindham Chaudhray","ac@gmail.com",'m');
	System.out.println(a);
	Book b=new Book("Discover The diamond in You",a,200,250);
	System.out.println(b);
	b.setPrice(240);
    b.setQtyInstock(90);
    System.out.println(b);  
    System.out.println("The Name of the book is: " + b.getName());
    System.out.println("Its Price: " + b.getPrice());
    System.out.println("The Quantity left: " + b.getQtyInstock());
    System.out.println("by: " + b.getAuthor());  
    System.out.println("Author's name is: " + b.getAuthor().getName());
    System.out.println("Author's email is: " + b.getAuthor().getEmail());
    System.out.println("Author's gender is: " + b.getAuthor().getGender());

    
    Book b1 = new Book("ABC",
          new Author("DEF", "abc@def.com", 'f'), 
          299, 18);
    System.out.println(b1); 
    sc.close();
}
}
