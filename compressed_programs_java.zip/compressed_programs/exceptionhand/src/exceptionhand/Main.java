package exceptionhand;
import java.lang.*;
import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter two numbers to perform Arthimetic operations on:");
		try {
			int a=sc.nextInt();
			int b=sc.nextInt();
			sc.close();
			if(b>a) {
				throw new ArithmeticException("negative result");
				
			}
			
			System.out.println("Addition:"+(a+b)+"\n"+"Subtraction:"+(a-b)+"\n"+"Multiplication:"+(a*b)+"\n"+"Division:"+(a/b));
		}
		catch(ArithmeticException e)
		{
			System.out.println("Arithmetic Exception occurs");
		}
		finally {
			System.out.println("Operations are executed");
		}
		
	}

}
