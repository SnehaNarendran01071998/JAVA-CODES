package fibo;

public class A {
	
	public void cal(int n){
		int n1=0;
		int n2=1;
		while(n1<=n)
		{
		System.out.print(n1+" ");
		int sum=n1+n2;
		n1=n2;
		n2=sum;
	}}

}
