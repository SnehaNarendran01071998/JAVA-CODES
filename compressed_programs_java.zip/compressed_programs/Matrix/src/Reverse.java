
import java.util.*;


public class Reverse {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int i,j;
		System.out.print("Enter the Elements:");
		int a[][]=new int[2][2];
		for(i=0;i<2;i++)
		{
			for(j=0;j<2;j++) {
			a[i][j]=sc.nextInt();}
		}
		
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a[i].length/2;j++) {
				int temp=a[i][j];
				a[i][j]=a[i][a[i].length-1-j];
				a[i][a[i].length-1-j]=temp;
				
			}
		}
		for(i=0;i<a.length;i++)
		{
			for(j=0;j<a.length;j++) {
			System.out.println(a[i][j]+" ");}
		}
		
		sc.close();
	}

}
