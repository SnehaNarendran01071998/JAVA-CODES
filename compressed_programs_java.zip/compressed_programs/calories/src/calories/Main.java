package calories;
import java.util.*;
class calories
{
	int bread=74;
	int butter=102;
	int jam=26;
	int slice;
	int tjam;
	int tbut;
	int calo;
	int calculateCalories(int slice)
	{
		
		calo=bread*slice;
		return calo;
	}
	int calculateCalories(int slice,int tjam)
	{
		calo=bread*slice+jam*tjam;
		return calo;
	}
	int calculateCalories(int slice,int tjam,int tbut)
	{
		calo=bread*slice+butter*tbut+jam*tjam;
		return calo;
	}
	int returnCalories(int calo)
		{
		return calo;
	}
	void calculateEnerg(int calo)
	{
		double e=calo*4.1868;
		System.out.println(e+" of energy generated from "+calo+" calories");
	}
}
public class Main {
	public static void main(String[] args)
	{
		calories c=new calories();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice: 1-Bread only"+"\n"+"2-Bread+jam"+"\n"+"3-Bread+Jam+butter");
		int slicno,tjam,tbut;
		int n=sc.nextInt();
		switch(n)
		{
		case 1:
			System.out.println("Enter the number of Slice of bread");
			slicno=sc.nextInt();
			int cal=c.calculateCalories(slicno);
			c.calculateEnerg(cal);
			break;
		case 2:
			System.out.println("Enter the number of Slice of bread");
			slicno=sc.nextInt();
			System.out.println("Enter the number of teaspoon of Jam");
			tjam=sc.nextInt();
			cal=c.calculateCalories(slicno,tjam);
			c.calculateEnerg(cal);
			break;
		case 3:
			System.out.println("Enter the number of Slice of bread");
			slicno=sc.nextInt();
			System.out.println("Enter the number of teaspoon of Jam");
			tjam=sc.nextInt();
			System.out.println("Enter the number of teaspoon of Butter");
			tbut=sc.nextInt();
			cal=c.calculateCalories(slicno,tjam,tbut);
			c.calculateEnerg(cal);
			break;
			
			
		}
		
	}

}
